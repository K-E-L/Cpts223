/**
 *  Basic hash table implementation
 *   Aaron S. Crandall - 2017 <acrandal@gmail.com>
 *
 */

#ifndef __HASH_H
#define __HASH_H

#include <unordered_map>
#include <list>
#include <string>
#include <iostream>
#include <time.h>

using namespace std;


/*
  private:
  void rehash();
  int hash_function(KEYTYPE key);
		
  public:
  bool insert(KEYTYPE key, VALTYPE val);
  bool contains(KEYTYPE key);
  int remove(KEYTYPE key);
  VALTYPE* find(KEYTYPE key);
  int size();            // Elements currently in table
  bool empty();          // Is the hash empty?
  float load_factor();   // Return current load factor
  void clear();          // Empty out the table
  int bucket_count();    // Total number of buckets in table
*/

template <typename KEYTYPE, typename VALTYPE>
  class Hashtable
{
 private:
  // REMOVE for PA
  unordered_map<KEYTYPE, VALTYPE> _hash;
  // END REMOVE

  // main hash table table
  // vector< type > _hash;

  // current table size
  int tableSize;

  /**
   *  Rehash the table into a larger table when the load factor is too large
   */
  void rehash()
  {
    int nextPrime = tableSize;
    bool found = false;

    if( nextPrime != 101 ) { nextPrime *= 2; }
    while ( !found ) {
      ++nextPrime;
      if ( isPrime( nextPrime ))
	found = true;
    }

    _hash.rehash( nextPrime );
  }

  bool isPrime( int n )
  {
    for (int i = 2; i <= n/2; ++i) {
      if (n % i == 0)
	  return false;
    }
      
    return true;
  }

  /**
   *  Function that takes the key (a string or int) and returns the hash key
   *   This function needs to be implemented for several types it could be used with!
   */
  int hash_function(int & key) {
    cout << " Hashing with int type keys." << endl;

    unsigned int hashVal = 0;

    hashVal = 37 * key;

    return hashVal % tableSize;
  }

  // & key updated from key
  int hash_function(string & key) {
    cout << " Hashing with string type keys." << endl;

    unsigned int hashVal = 0;

    for( char ch : key )
      hashVal = 37 * hashVal + ch;

    return hashVal % tableSize;
  }

		
 public:
  /**
   *  Basic constructor
   */
  Hashtable( int startingSize = 101 )
    {
      tableSize = startingSize;
    }

  // made myself
  // fix for linked lists
  void findDefinition( KEYTYPE key ) {

    if ( _hash[ key ].definition != "" )
      cout << "Definition: " << _hash[ key ].definition << endl;

    else
      cout << "Unknown Word" << endl;
    
  }

  void printTable() {
      for ( auto temp = _hash.begin(); temp != _hash.end(); ++temp )
	cout << "Word: " << temp->first << " Definition: " << temp->second.definition << endl;
  }

  void printTable( int num ) {

    int tempNum = 0;
    
    for ( auto temp = _hash.begin(); tempNum != num ; ++temp, ++tempNum )
      cout << "Word: " << temp->first << " Definition: " << temp->second.definition << endl;
  }


  // made myself
  // fix for linked lists
  void printWord( KEYTYPE key ) {

    /* map<...> _dict; */
    /* iterator item = _dict.begin(); */
    /* advance( item, random_0_to_n(_dict.size())); */
    

    
    /* srand(time(NULL)); */
    
    /* while ( _hash[ key ].definition != "" ) { */
    /*   key = to_string(rand()); */
    /*   cout << "key: " << key << endl; */
    /* } */
    
    cout << "Word: " << _hash[ key ].myword;
    cout << "   Definition: " << _hash[ key ].definition << endl;
  }

  /**
   *  Add an element to the hash table
   */
  bool insert(KEYTYPE key, VALTYPE val) {

    VALTYPE * temp = _hash[ key ].nextPointer;


    if ( _hash[ key ].definition == "" ) {
      /* cout << "key: " << key << endl; */
      /* cout << "val.myword: " << val.myword << endl; */
      /* cout << "val.definition: " << val.definition << endl; */

      _hash[ key ] = val;
    }
    

    // never happens, kinda sketch
    else
      {
	VALTYPE * temp1 = new VALTYPE("", "" );
	    
    	while ( temp != nullptr )
    	  {
    	    temp = temp->nextPointer;
    	  }

    	temp->nextPointer = temp1;
      }

    /* cout << "myword: " << _hash[ key ].myword << endl; */
    /* cout << "definition: " << _hash[ key ].definition << endl; */
  }

  /**
   *  Return whether a given key is present in the hash table
   */
  bool contains(KEYTYPE key) {
    _hash.find(key);
  }


  /**
   *  Completely remove key from hash table
   *   Returns number of elements removed
   */
  int remove(KEYTYPE key) {
    _hash.erase( key );
  }

  /**
   *  Searches the hash and returns a pointer
   *   Pointer to Word if found, or nullptr if nothing matches
   */
  VALTYPE* find(KEYTYPE key) {
    // when collisions are found, add in linked list stuff
    if ( _hash[ key ].definition == "" )
      return nullptr;

    else {
      VALTYPE * tempNode = new VALTYPE( "" , "" );

      tempNode->myword = key;
      tempNode->definition = _hash[ key ].definition;

      return tempNode;
    }
  }

  /**
   *  Return current number of elements in hash table
   */
  int size() {
    return _hash.size();
  }

  /**
   *  Return true if hash table is empty, false otherwise
   */
  bool empty() {
    return _hash.empty(); 
  }

  /**
   *  Calculates the current load factor for the hash
   */
  float load_factor() {
    return _hash.load_factor();
  }

  /**
   *  Returns current number of buckets (elements in vector)
   */
  int bucket_count() {
    return _hash.bucket_count();
  }

  /**
   *  Deletes all elements in the hash
   */
  void clear() {

    // must delete the linked lists first
    // otherwise memory leak
    
    _hash.clear();
  }

};


#endif
