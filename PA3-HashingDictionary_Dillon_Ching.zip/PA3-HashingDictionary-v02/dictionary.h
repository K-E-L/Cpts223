#ifndef __DICT_H
#define __DICT_H

#include "hashtable.h"
#include "word.h"
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <time.h>


using namespace std;

class Dictionary
{

 private:
  Hashtable<string, Word> _dict;  // Primary dictionary store

  void parseline( string line ) {
    cout << " [d] Parsing line: " << line << endl;


    if ( line == "help" || line == "clear" ||
	 line == "size" || line == "random" || line == "quit" || line == "print" ) {
      if ( line == "help" ) { help(); }
      else if ( line == "clear" ) { clear(); }
      else if ( line == "size" ) { size(); }
      else if ( line == "random" ) { random(); }
      else if ( line == "print" ) { print(); }
    }

    else {
      size_t pos = line.find( " " );
      string instruction = line.substr( pos + 1 );
      string command = line.substr( 0, pos );
	  
      if ( command == "add" ) {
	add( instruction );
      }

      else if ( command == "remove" ) {
	remove( instruction );
      }

      else if ( command == "define" ) {
	define( instruction );
      }

      else if ( command == "load" ) {
	load( instruction );
      }

      else if ( command == "unload" ) {
	unload( instruction );
      }

      else if ( command == "print" ) {
	print( instruction );
      }
 
    }
      

    
    //    string command = line.substr();


    
    // look for: add, remove, define, load, unload,
    // single words: size, print, random, quit
  }

  // help -> print out command help
  void help() {
    cout << "Help Page" << endl;
    cout << "help: Interface to help the user use commands" << endl; 
    cout << "add: Add (or update!) a word and it's definition" << endl; 
    cout << "remove: Remove a given word" << endl;
    cout << "define: Define a word by printing out its definition or 'unknown word'" << endl;
    cout << "load: Load in a JSON file of dictionary words" << endl;
    cout << "unload: Remove words from a given JSON file of dictionary words" << endl;
    cout << "size: Print out current number of words in the dictionary" << endl;
    cout << "clear: Remove ALL words from the dictionary" << endl;
    cout << "print: Print out all words, unless user gives a maximum number" << endl;
    cout << "random: Print out a single word chosen randomly from the dictionary" << endl;
    cout << "quit: Quits the program" << endl;
  }

  // add "word" "definition" -> Add (or update!) a word and it's definition. Must handle quotes
  void add( string line ) {
    // needs work on the linked list portion
    
    for( string::iterator i = line.begin(); i != line.end(); i++ ) {
      if( !isalpha( line.at( i - line.begin())) &&  !isdigit( line.at( i - line.begin())) && line.at( i - line.begin()) != ' ' && line.at( i - line.begin()) != '-' ) {
	line.erase( i );
	i--;
      }
    }

    size_t pos = line.find( " " );
    string word = line.substr( 0, pos );
    string definition = line.substr( pos + 1 );

    transform( word.begin(), word.end(), word.begin(), ::tolower );
	
    cout << "adding.. ";
    cout << "word: " << word << endl;
    
    _dict.insert( word, Word{ word, definition } );
  }
  
  // remove "word" -> Remove a given word. Must handle auotes
  void remove( string line) {
    transform( line.begin(), line.end(), line.begin(), ::tolower );
    
    cout << "removing.. ";
    cout << "word: " << line << endl;

    _dict.remove( line );
  }

  // define "word" -> Define a word by printing out its definition or "unknown word"
  void define( string line ) {
    transform( line.begin(), line.end(), line.begin(), ::tolower );
    _dict.findDefinition( line );
  }

  // load "fileneame" -> Load in a JSON file of dictionary words
  void load( string line ) {
    std::ifstream file( line , std::ifstream::binary );

    if ( !file ) {
      cout << "couldn't read file" << endl;
      return;
    }

    string garbage, temp;

    getline( file, garbage );
    getline( file, garbage );

    while ( getline( file, temp ) ) {
      
      if ( temp == "  ]" )
	break;

      for( string::iterator i = temp.begin(); i != temp.end(); i++ ) {
	if( !isalpha( temp.at( i - temp.begin())) &&  !isdigit( temp.at( i - temp.begin())) && temp.at( i - temp.begin()) != ' ' && temp.at( i - temp.begin()) != '-' && temp.at( i - temp.begin()) != '.') {
	  temp.erase( i );
	  i--;
	}
      }

      size_t pos = temp.find( " " );
    
      string noGarbage = temp.substr( pos + 4 );
      pos = noGarbage.find( " " );

      noGarbage = noGarbage.substr( pos + 1 );
      pos = noGarbage.find( " " );
    
      string word = noGarbage.substr( 0, pos );
      transform( word.begin(), word.end(), word.begin(), ::tolower );

      noGarbage = noGarbage.substr( pos + 1 );
      pos = noGarbage.find( " " );

      string trash = noGarbage.substr( 0, pos );
      string definition = noGarbage.substr( pos + 1 );
    
      _dict.insert( word, Word{ word, definition } );
    }
  }

  // unload "filename" -> Remove words from a given JSON file of dictionary words
  void unload( string line ) {
    cout << "unloading.. " << endl;
    _dict.clear();
  }

  // size -> Print out current number of words in the dictionary
  void size() {
    cout << "dictionary size: " << _dict.size() << endl;
  }

  // clear -> Remove ALL words from the dictionary
  void clear() {
    cout << "clearing.. " << endl;
    _dict.clear();
  }

  // print [#words] -> Print out all words, unless user gives a maximum number
  void print( string line ) {

    string::size_type sz;
    size_t pos = line.find( " " );
    string word = line.substr( 0, pos );
    string definition = line.substr( pos + 1 );

    int def = stoi( definition, &sz );
    
    _dict.printTable( def );
  }

  void print() {
    _dict.printTable();
  }

  // random -> Print out a single word chosen randomly from the dictionary
  void random() {

    /* srand(time(NULL)); */

    
    
    /* for ( auto temp = _dict.begin(); temp != _dict.end(); temp += rand() ) */
    /*   cout << "Word: " << temp->first << " Definition: " << temp->second.definition << endl; */

    /* string temp = "asdf"; */
    
    /* _dict.printWord( temp ); */
  }

  

 public:
  Dictionary()	// Default constructor
    { }

  /**
   *  Run the main dictionary user interface
   */
  void run_ui() {
    // print out header
    cout << "+------------------------------------------+" << endl;
    cout << "|-- Welcome to the best dictionary evar! --|" << endl;
    cout << "+------------------------------------------+" << endl;


    string instr;
    cout << " Enter command (C-d or EOF quits): ";

    // read in user input until eof
    // or until quit has been read
    

    while ( getline(cin, instr) ) {
      cout << "Entered: " << instr << endl;
      parseline(instr);
      // call function based on line contents
      // print results

      if ( instr == "quit" ) { break; }

      cout << "Enter command: ";
    }
    cout << endl;
  }

};



#endif
